

function CardBlank({ activity }) {
	return (
		<div className="w-[9rem] bg-[#BBBBBB]">
			<div className="w-[95%] h-[150px] p-2  m-1"></div>
		</div>
	)
}

export default CardBlank
